Imports ATSMS

Public Class MainForm

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    
    Private Sub btnPhone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPhone.Click

        If cboComPort.Text = String.Empty Then
            MsgBox("COM Port must be selected", MsgBoxStyle.Information)
            Return
        End If

        Dim oGsmModem As New GSMModem

        oGsmModem.Port = cboComPort.Text

        If cboBaudRate.Text <> String.Empty Then
            oGsmModem.BaudRate = Convert.ToInt32(cboBaudRate.Text)
        End If

        If cboDataBit.Text <> String.Empty Then
            oGsmModem.DataBits = Convert.ToInt32(cboDataBit.Text)
        End If

        If cboStopBit.Text <> String.Empty Then
            Select Case cboStopBit.Text
                Case "1"
                    oGsmModem.StopBits = Common.EnumStopBits.One
                Case "1.5"
                    oGsmModem.StopBits = Common.EnumStopBits.OnePointFive
                Case "2"
                    oGsmModem.StopBits = Common.EnumStopBits.Two
            End Select
        End If

        If cboFlowControl.Text <> String.Empty Then
            Select Case cboFlowControl.Text
                Case "None"
                    oGsmModem.FlowControl = Common.EnumFlowControl.None
                Case "Hardware"
                    oGsmModem.FlowControl = Common.EnumFlowControl.RTS_CTS
                Case "Xon/Xoff"
                    oGsmModem.FlowControl = Common.EnumFlowControl.Xon_Xoff
            End Select
        End If

        Try
            oGsmModem.Connect()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
            Return
        End Try

        Try
            txtRevision.Text = oGsmModem.Revision
        Catch ex As Exception
            txtRevision.Text = "Not supported"
        End Try

        Try
            txtIMSI.Text = oGsmModem.IMSI
        Catch ex As Exception
            txtIMSI.Text = "Not supported"
        End Try

        Try
            txtIMEI.Text = oGsmModem.IMEI
        Catch ex As Exception
            txtIMEI.Text = "Not supported"
        End Try

        Try
            txtModel.Text = oGsmModem.PhoneModel
        Catch ex As Exception
            txtModel.Text = "Not supported"
        End Try

        Try
            txtManufacturer.Text = oGsmModem.Manufacturer
        Catch ex As Exception
            txtManufacturer.Text = "Not supported"
        End Try

     

        Try
            txtSMSC.Text = oGsmModem.SMSC
        Catch ex As Exception
            txtSMSC.Text = "Not supported"
        End Try


        Try
            Dim rssi As Rssi = oGsmModem.GetRssi
            txtSignal.Text = rssi.Current & " of " & rssi.Maximum
        Catch ex As Exception
            txtSignal.Text = "Not supported"
        End Try

        Try
            Dim storages() As Storage = oGsmModem.GetStorageSetting
            Dim i As Integer
            txtSupportedStorage.Text = String.Empty
            For i = 0 To storages.Length - 1
                Dim storage As Storage = storages(i)
                txtSupportedStorage.Text += storage.Name & "(" & storage.Used & "/" & storage.Total & "), "
            Next
        Catch ex As Exception
            txtSupportedStorage.Text = "Not supported"
        End Try

        Try
            Dim loc As Location = oGsmModem.GetLocation
            txtLocation.Text = "Cell Id: " & loc.CellID & ", MNC: " & loc.MNC & ", MCC: " & loc.MCC & ", LAI: " & loc.LAI
        Catch ex As Exception
            txtLocation.Text = "Not supported"
        End Try

        Try
            txtPhoneNumber.Text = oGsmModem.MSISDN
        Catch ex As Exception
            txtPhoneNumber.Text = "Not supported"
        End Try

        Try
            Dim battery As Battery = oGsmModem.GetBatteryLevel
            txtBattery.Text = battery.BatteryLevel & "/" & battery.MaximumLevel & "(Charging: " & battery.BatteryCharged & ")"
        Catch ex As Exception
            txtBattery.Text = "Not supported"
        End Try

    End Sub

    
End Class
