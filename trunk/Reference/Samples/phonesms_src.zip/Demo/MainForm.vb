Imports ATSMS

Public Class MainForm

    Private oGsmModem As New GSMModem

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    
    Private Sub btnPhone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click

        If cboComPort.Text = String.Empty Then
            MsgBox("COM Port must be selected", MsgBoxStyle.Information)
            Return
        End If

        oGsmModem.Port = cboComPort.Text

        If cboBaudRate.Text <> String.Empty Then
            oGsmModem.BaudRate = Convert.ToInt32(cboBaudRate.Text)
        End If

        If cboDataBit.Text <> String.Empty Then
            oGsmModem.DataBits = Convert.ToInt32(cboDataBit.Text)
        End If

        If cboStopBit.Text <> String.Empty Then
            Select Case cboStopBit.Text
                Case "1"
                    oGsmModem.StopBits = Common.EnumStopBits.One
                Case "1.5"
                    oGsmModem.StopBits = Common.EnumStopBits.OnePointFive
                Case "2"
                    oGsmModem.StopBits = Common.EnumStopBits.Two
            End Select
        End If

        If cboFlowControl.Text <> String.Empty Then
            Select Case cboFlowControl.Text
                Case "None"
                    oGsmModem.FlowControl = Common.EnumFlowControl.None
                Case "Hardware"
                    oGsmModem.FlowControl = Common.EnumFlowControl.RTS_CTS
                Case "Xon/Xoff"
                    oGsmModem.FlowControl = Common.EnumFlowControl.Xon_Xoff
            End Select
        End If

        Try
            oGsmModem.Connect()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
            Return
        End Try

        btnSend.Enabled = True
        btnDisconnect.Enabled = True

        MsgBox("Connected to phone successfully !", MsgBoxStyle.Information)

    End Sub

    
    Private Sub btnDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisconnect.Click
        Try
            oGsmModem.Disconnect()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try

        btnSend.Enabled = False
        btnDisconnect.Enabled = False
        btnConnect.Enabled = True

    End Sub

    Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
        If txtPhoneNumber.Text.Trim = String.Empty Then
            MsgBox("Phone number must not be empty", MsgBoxStyle.Critical)
            Return
        End If

        If txtMsg.Text.Trim = String.Empty Then
            MsgBox("Phone number must not be empty", MsgBoxStyle.Critical)
            Return
        End If

        Try
            Dim msg As String = txtMsg.Text.Trim
            Dim msgNo As String
            If StringUtils.IsUnicode(msg) Then
                msgNo = oGsmModem.SendSMS(txtPhoneNumber.Text, msg, Common.EnumEncoding.Unicode_16Bit)
            Else
                msgNo = oGsmModem.SendSMS(txtPhoneNumber.Text, msg, Common.EnumEncoding.GSM_Default_7Bit)
            End If
            MsgBox("Message is sent. Reference no is " & msgNo, MsgBoxStyle.Information)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try

        Try
            Dim storages() As Storage = oGsmModem.GetStorageSetting
            Dim i As Integer
            txtStorage.Text = String.Empty
            For i = 0 To storages.Length - 1
                Dim storage As Storage = storages(i)
                txtStorage.Text += storage.Name & "(" & storage.Used & "/" & storage.Total & "), "
            Next
        Catch ex As Exception
            txtStorage.Text = "Not supported"
        End Try
    End Sub
End Class
